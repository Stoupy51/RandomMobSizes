
#> random_mob_sizes:get_mob_individual_config
#
# @executed	as @e[type=!player,tag=!...,predicate=random_mob_sizes:has_brain]
#
# @within	random_mob_sizes:apply_random_size with storage random_mob_sizes:macro
#
# @args		entity_type (unknown)
#

# If individual config exists, use it
$data modify storage random_mob_sizes:temp found_mob set from storage random_mob_sizes:config mobs."$(entity_type)"
execute if data storage random_mob_sizes:temp found_mob.min_size run data modify storage random_mob_sizes:temp mob_config.min_size set from storage random_mob_sizes:temp found_mob.min_size
execute if data storage random_mob_sizes:temp found_mob.max_size run data modify storage random_mob_sizes:temp mob_config.max_size set from storage random_mob_sizes:temp found_mob.max_size
execute if data storage random_mob_sizes:temp found_mob.health_scale run data modify storage random_mob_sizes:temp mob_config.health_scale set from storage random_mob_sizes:temp found_mob.health_scale
execute if data storage random_mob_sizes:temp found_mob.speed_scale run data modify storage random_mob_sizes:temp mob_config.speed_scale set from storage random_mob_sizes:temp found_mob.speed_scale
execute if data storage random_mob_sizes:temp found_mob.damage_scale run data modify storage random_mob_sizes:temp mob_config.damage_scale set from storage random_mob_sizes:temp found_mob.damage_scale
data remove storage random_mob_sizes:temp found_mob

