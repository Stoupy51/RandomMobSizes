
#> random_mob_sizes:v1.3.5/load/secondary
#
# @within	random_mob_sizes:v1.3.5/load/main
#

# RandomMobSizes
scoreboard objectives add random_mob_sizes.data dummy
tag Stoupy51 add convention.debug

# Confirm load
function random_mob_sizes:v1.3.5/load/confirm_load

